using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IDCardAutomation.Pages.Account
{
    public class EntryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
