using IDCardAutomation.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IDCardAutomation.Account
{
    public class SignInModel : PageModel
    {
        private readonly AuthService _authService;

        public SignInModel(AuthService authService) => _authService = authService;

        [BindProperty] public string Email { get; set; }
        [BindProperty] public string Password { get; set; }

        public IActionResult OnPost()
        {
            if (_authService.ValidateUser(Email, Password))
            {
                // Set cookie/session if needed
                return RedirectToPage("/Index");
            }

            ModelState.AddModelError("", "Invalid credentials");
            return Page();
        }
    }
}